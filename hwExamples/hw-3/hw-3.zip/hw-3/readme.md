Michael Musick, 50
["Hello World!" Sketch](https://michaelmusick.github.io/120-work/hw-3/)

# Homework 3 Response

This week was interesting as we started to dig into p5. I felt as though we would tackle more challenging work, but understand that we probably need to start slow... **(You would keep going with your response)**
