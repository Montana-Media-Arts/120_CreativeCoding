Michael Musick, 50

[Live Sketch Link](https://montana-media-arts.github.io/120_CreativeCoding_Fall2017/hwExamples/HW-5/)


# HW-5 -- Animation & Variables

For this week, I wanted to create a creepy, variable-based, spinning head person. The goal of this was to;

- utilize p5 reserved word variables, such as `mouseX`,
- declare and use my own variables,
- explore simple variable math,
- and create a sketch that moves around the page.

## Difficulties

I found... _{you would continue on}_
