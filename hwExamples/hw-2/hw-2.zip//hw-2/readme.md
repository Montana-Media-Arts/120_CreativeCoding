Michael Musick 50

# HW-2 Response Document

This week was a struggle for me. The concepts, were so abstract, that it was difficult to understand why we are doing some of the things we are doing. In addition, I keep getting really confused by the term "directory". I know it means folder, but

## Image Example

![This is an example screen image](./editor_image.png)
