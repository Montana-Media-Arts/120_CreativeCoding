# HW-6 Example for MART120 - Creative Coding

This is a simple algorithmic piece that uses perlin noise, and random number generators to draw triangles always connected by two corners to the previous triangle.

#### [Link to Live Example](https://montana-media-arts.github.io/120_CreativeCoding_Fall2017/hwExamples/HW-6/)
