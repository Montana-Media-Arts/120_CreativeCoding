Michael Musick, 50

[Live Sketch Link](https://montana-media-arts.github.io/120_CreativeCoding_Fall2017/hwExamples/HW-4/)


# HW-4 -- Self Portrait

This week I finally dug into p5.js and made a Self-Portrait (reinterpreted as a monster).

etc.............


## Final Picture

Here is a screen shot of my sketch.
![Screen shot of my sketch](imgs/selfportrait.png "Screen shot of my monster sketch")
