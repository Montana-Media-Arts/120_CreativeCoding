Michael Musick, 50

[Live Sketch Link](https://montana-media-arts.github.io/120_CreativeCoding_Fall2017/hwExamples/HW-4_02/)


# HW-4 -- Self Portrait

This week I finally dug into p5.js and made a Self-Portrait (reinterpreted as a monster).

etc.............
