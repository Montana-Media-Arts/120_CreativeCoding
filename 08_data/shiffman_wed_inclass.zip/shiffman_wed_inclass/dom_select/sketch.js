var button;



function setup() {
  var canvas = createCanvas(200, 200);
  canvas.parent('container');
  
  var p = select('#a');
  //p.style('border-style', 'solid');

  button = select('#clicker');
  button.mousePressed(changestuff);

  var peanut = select('#peanut');
  peanut.mousePressed(changestuff);
}

function draw() {
  background(0);
}

function changestuff() {
  var elements = selectAll('.Sol');
  for (var i = 0; i < elements.length; i++) {
    elements[i].html('I am element ' + i);
  }

  button.html("I am clicked.");
}