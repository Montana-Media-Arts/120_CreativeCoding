
var url1 = 'http://api.wordnik.com:80/v4/word.json/';
var url2 = '/definitions?limit=2&includeRelated=true&sourceDictionaries=all&useCanonical=false&includeTags=false&api_key=a2a73e7b926c924fad7001ca3111acd55af2ffabf50eb4ae5';

var input, submit;

function setup() {
  noCanvas();
  
  input = select('#userinput');
  submit = select('#submit');
  submit.mousePressed(runQuery);
}

function runQuery() {
  var word = input.value();
  loadJSON(url1 + word + url2, gotData);
}


function gotData(data) {
  for (var i = 0; i < data.length; i++) {
    var p = createP(data[i].text);
    p.style('font-size', '24pt');
  }
  //space = data;

}