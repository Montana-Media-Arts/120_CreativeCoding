var a = "http://api.nytimes.com/svc/search/v2/articlesearch.json";
var b = "?q="; //halloween";
var c = "&begin_date="; //20150101";
var d = "&end_date="; //20151231";
var e = "&sort=oldest&api-key=sample-key&facet_field=source&facet_filter=true";

var input;

function setup() {
  noCanvas();
  input = createInput();
  var button = createButton('submit');
  button.mousePressed(runQuery);
}

function runQuery() {
  var start = "20150101";
  var end = "20151231";
  loadJSON(a + b + input.value() + c + start + d + end + e, gotData);
}

function gotData(data) {
  createP(input.value());
  createDiv(data.response.facets.source.terms[0].count);
}