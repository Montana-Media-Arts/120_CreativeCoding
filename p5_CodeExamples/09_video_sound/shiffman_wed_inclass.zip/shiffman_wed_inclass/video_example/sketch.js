var video;
var canvas;

function setup() {
  canvas = createCanvas(320, 240);
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();
}

function draw() {
  background(255, 0, 150);
  image(video, 0, 0, mouseX, mouseY);
  rect(50,25,300,10);

}