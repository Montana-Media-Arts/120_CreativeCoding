var a = "http://api.nytimes.com/svc/search/v2/articlesearch.json";
var b = "?q="; //halloween";
var c = "&begin_date="; //20150101";
var d = "&end_date="; //20151231";
var e = "&sort=oldest&api-key=sample-key&facet_field=source&facet_filter=true";


function setup() {
  askNYTimes("halloween", "20150101", "20151231");
  askNYTimes("new years eve", "20150101", "20151231");
  askNYTimes("halloween", "19500101", "19501231");
  askNYTimes("new years eve", "19500101", "19501231");


  //term = "new years eve";


}


function askNYTimes(term, start, end) {
  loadJSON(a + b + term + c + start + d + end + e, gotData);

  function gotData(data) {
    createP(term + " " + start);
    createDiv(data.response.facets.source.terms[0].count);
  }
}