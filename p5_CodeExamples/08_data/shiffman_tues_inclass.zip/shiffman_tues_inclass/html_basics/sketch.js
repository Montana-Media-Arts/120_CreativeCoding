var p1;
var p2;
function setup() {
  p1 = createP("Look, it's a number: " + random(10));
  p1.mouseOver(changeColor1);
  p1.mouseOut(revertColor1);
  p2 = select("#purple");
  p2.mouseOver(changeColor2);
  var canvas = createCanvas(200, 200);
  //canvas.position(10, 100);
  canvas.parent("canvas_div");
}

function changeColor1() {
  p1.style('background-color', 'purple');
  p1.style('color', 'white');
  p1.style('padding', '24px');
}
function revertColor1() {
  p1.style('background-color', 'white');
}

function changeColor2() {
  p2.style('background-color', 'purple');
}


function draw() {
  background(0);
  ellipse(100, 100, 20, 20);
}