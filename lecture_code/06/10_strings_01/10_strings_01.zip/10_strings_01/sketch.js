function setup() {
    createCanvas( windowWidth, 200 );

    var text2Print = "This is some text in a string!!!";
    textSize( 34 );
    text( text2Print, 10, height/2 );
}
