# Information on setting up your dev environment 

[Link to tweaking and installing Atom text editor. ](https://montana-media-arts.github.io/mart341-webDev/modules/week-2/texteditor/)


MAC USERS: Please work through the following on [Git in Terminal](https://montana-media-arts.github.io/mart341-webDev/modules/week-2/git-version-control/)
