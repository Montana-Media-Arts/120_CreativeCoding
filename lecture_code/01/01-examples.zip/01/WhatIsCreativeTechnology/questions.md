# Questions about Creative Technology


1. What is "creative technology" or "creative coding"?


2. Is Creative Technology or Creative Coding an 'art form'?


3. What is a Media Artist? And, what is the difference, if any, between a media artist and creative technologist?


4. How do you see Creative Technology fitting into the larger trends and flows of art?


5. What is the relationship today between science and art?


6. What is the historical relationship between science and art?
