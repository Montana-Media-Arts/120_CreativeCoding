function setup(){
    // create a canvas that is
    // (width:400px, height:400px)
    createCanvas(400,400);
}

function draw() {
    // set the background to 'white'
    background(255);

    // no rotate
    // translate to (x:250, y:75)
    // smiley centered at (x:75, y:75)
    translate( 250, 75 );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

    // rotate 45°
    // translate to (x:75, y:75)
    // smiley centered at (x:150, y:150)
    translate( 75, 75 );
    rotate( radians(45) );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

    // rotate 45°
    // translate to (x:75, y:75)
    // smiley centered at (x:225, y:225)
    translate( 75, 75 );
    rotate( radians(45) );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

    // rotate 45°
    // translate to (x:75, y:75)
    // smiley centered at (x:300, y:300)
    translate( 75, 75 );
    rotate( radians(45) );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

    // rotate 45°
    // translate to (x:75, y:75)
    // smiley centered at (x:300, y:300)
    translate( 75, 75 );
    rotate( radians(45) );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

    // rotate 45°
    // translate to (x:75, y:75)
    // smiley centered at (x:300, y:300)
    translate( 75, 75 );
    rotate( radians(45) );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

    // rotate 45°
    // translate to (x:75, y:75)
    // smiley centered at (x:300, y:300)
    translate( 75, 75 );
    rotate( radians(45) );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

    // rotate 45°
    // translate to (x:75, y:75)
    // smiley centered at (x:300, y:300)
    translate( 75, 75 );
    rotate( radians(45) );
    // ** draw the smily face **
    stroke( 0 );
    fill('rgba(234, 255, 61, 0.5)');
    ellipse( 0, 0, 100 );
    noStroke();
    fill( 40, 127 );
    arc( 0, 15, 75, 50, 0, PI );
    ellipse( -20, -15, 20 );
    ellipse( 20, -15, 20 );

}
