function setup() {
    createCanvas( 300, 100 );
    background( '#c8f1f9' );
}

function draw() {
    point(30, 20);
    point(85, 20);
    point(85, 75);
    point(30, 75);
}
