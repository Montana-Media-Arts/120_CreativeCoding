function setup() {
    // first we need to specify our canvas size
    createCanvas( 800, 400 );

    // Try replacing one of the integer values in the below RGB color function.
    // NOTE: Be sure to keep the rgb() function surrounded with quotes.
    background( 'rgb(255, 123, 2)' );
}
