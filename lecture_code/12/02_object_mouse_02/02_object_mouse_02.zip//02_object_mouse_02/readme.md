Empty p5 sketch.

Please replace contents of this file with appropriate readme information after finishing your p5 sketch.
