function setup(){
    createCanvas( windowWidth, 400 );
}

function draw() {
    background( 'rgb(91, 255, 147)' );
    ellipse( 150, 150, 150 );
}
