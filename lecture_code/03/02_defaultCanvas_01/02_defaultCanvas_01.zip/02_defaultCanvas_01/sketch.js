function setup() {
    // notice there is no canvas command in the sketch file
    // blue background to demonstrate default canvas size
    background('blue');
}
