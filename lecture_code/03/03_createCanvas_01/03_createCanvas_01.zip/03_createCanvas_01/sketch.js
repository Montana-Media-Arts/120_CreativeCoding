function setup(){
    // Change the number in the createCanvas() function
    createCanvas( 600, 400 );

    // Ignore this line for the moment,
    // This is what is "coloring" the canvas
    background( 'blue' );
}
