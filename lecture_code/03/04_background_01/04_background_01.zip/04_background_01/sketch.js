function setup() {
    // first we need to specify our canvas size
    createCanvas( 800, 400 );

    // Then we can color this background
    // Notice how the word 'blue' is surrounded in quotes
    background('blue');
    // Try replacing the word 'blue' with other common color names.
    // NOTE: Be sure to keep the word surrounded with quotes.
}
