function setup(){
    text("Hello World!", 0, 10);
}
