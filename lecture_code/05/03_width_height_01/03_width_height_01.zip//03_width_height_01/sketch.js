
function setup() {
    createCanvas( 500, 200 );
}

function draw() {
    background( 'rgb(87, 219, 147)' );

    textSize(36);
    text("width: " + width, 10, 40);
    text("height: " + height, 10, 80);
}
