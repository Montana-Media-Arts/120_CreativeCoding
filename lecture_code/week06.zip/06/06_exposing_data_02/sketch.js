function setup() {
    createCanvas( windowWidth, 400 );
    background( 'grey' );
}

var global_var = "Hello There!";
