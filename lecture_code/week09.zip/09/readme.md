# Wednesday March 8th

- More on Functions
- Arrays
- and Objects!



Info on Array's
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array
