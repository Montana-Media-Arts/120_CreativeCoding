// var weather = {
//   temp: 72,
//   status: "raining"
// }

var weather;

function preload() {
  weather = loadJSON('weather.json');  
}

function setup() {
  createCanvas(200, 200);
  createP(weather.status);
}

function draw() {
  background(0);
  ellipse(100, 100, weather.temp, weather.temp);
}