var video;

function setup() {
  createCanvas(320,240);
  background(0);
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();
}

function draw() {
  background(255, 0, 150);
  
  image(video, 0, 0, mouseX, mouseY);
  ellipse(width/2, height/2, 20, 20);
}