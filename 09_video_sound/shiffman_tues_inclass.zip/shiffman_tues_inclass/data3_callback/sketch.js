// var weather = {
//   temp: 72,
//   status: "raining"
// }

var weather;

function setup() {
  createCanvas(200, 200);
  loadJSON('weather.json', gotData);
}

function gotData(data) {
  weather = data;
  createP(weather.status);
}

function draw() {
  background(0);
  //if (weather != undefined) {
  if (weather) {
    ellipse(100, 100, weather.temp, weather.temp);
  }

}